from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report, ConfusionMatrixDisplay,
    RocCurveDisplay)

ROOT=Path(__file__).resolve().parent
data=pd.read_csv(ROOT/"data"/"credit_scoring_synthetic.csv")
TARGET="defaulted"

print("Preview:\\n",data.head())
print("\\nShape:",data.shape)
print("\\nMissing values:\\n",data.isna().sum())
print("\\nTarget balance:\\n",data[TARGET].value_counts(normalize=True).round(3))

X=data.drop(columns=TARGET)   # Features: information used to make a prediction
y=data[TARGET]                # Target: 0 = no default, 1 = default

X_train,X_test,y_train,y_test=train_test_split(
    X,y,test_size=.2,random_state=42,stratify=y)

preprocess=ColumnTransformer([("numeric",Pipeline([
    ("imputer",SimpleImputer(strategy="median")),
    ("scaler",StandardScaler())]),X.columns.tolist())])

models={
 "Logistic Regression":LogisticRegression(max_iter=2000,class_weight="balanced"),
 "Decision Tree":DecisionTreeClassifier(max_depth=5,min_samples_leaf=10,
     class_weight="balanced",random_state=42),
 "Random Forest":RandomForestClassifier(n_estimators=250,max_depth=8,
     min_samples_leaf=5,class_weight="balanced",random_state=42,n_jobs=-1)
}

rows=[]; fitted={}
for name,estimator in models.items():
    model=Pipeline([("preprocessing",preprocess),("classifier",estimator)])
    model.fit(X_train,y_train)
    pred=model.predict(X_test)
    prob=model.predict_proba(X_test)[:,1]
    fitted[name]=model
    rows.append({"Model":name,
        "Accuracy":accuracy_score(y_test,pred),
        "Precision":precision_score(y_test,pred,zero_division=0),
        "Recall":recall_score(y_test,pred,zero_division=0),
        "F1":f1_score(y_test,pred,zero_division=0),
        "ROC-AUC":roc_auc_score(y_test,prob)})
    print("\\n",name,"\\n",classification_report(y_test,pred,zero_division=0))
    print("Confusion matrix:\\n",confusion_matrix(y_test,pred))

results=pd.DataFrame(rows).sort_values("ROC-AUC",ascending=False)
print("\\nMODEL COMPARISON\\n",results.round(3).to_string(index=False))
results.to_csv(ROOT/"model_comparison.csv",index=False)

best=results.iloc[0]["Model"]
fig,axes=plt.subplots(1,2,figsize=(12,5))
ConfusionMatrixDisplay.from_estimator(fitted[best],X_test,y_test,ax=axes[0],
    display_labels=["No default","Default"],colorbar=False)
axes[0].set_title("Confusion matrix: "+best)
for name,model in fitted.items():
    RocCurveDisplay.from_estimator(model,X_test,y_test,ax=axes[1],name=name)
axes[1].set_title("ROC curves")
plt.tight_layout()
plt.savefig(ROOT/"evaluation_plots.png",dpi=160)
print("\\nSaved model_comparison.csv and evaluation_plots.png")
print("Educational synthetic data only — not for real lending decisions.")
