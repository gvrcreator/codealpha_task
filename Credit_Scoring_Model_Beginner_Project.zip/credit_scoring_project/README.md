# Credit Scoring Model — Beginner Project

## What are we predicting?
This is a **binary classification** problem:
- `defaulted = 0`: the example applicant did not default.
- `defaulted = 1`: the example applicant defaulted.

The model uses applicant information (features) to estimate the target.

## Important
The included CSV is **synthetic educational data**, not real customer data and not a real bank's credit policy. This project must not be used to approve or reject actual loan applications.

## Project files
- `data/credit_scoring_synthetic.csv` — 1,000 generated example records.
- `main.py` — data inspection, train/test split, preprocessing, three models and evaluation.
- `requirements.txt` — required Python packages.

## Run on Windows
Open a terminal in this project folder and run:

```bash
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python main.py
```

The script creates `model_comparison.csv` and `evaluation_plots.png`.

## Dataset columns
| Column | Meaning |
|---|---|
| age | Age in years |
| monthly_income | Monthly income, in example currency units |
| existing_monthly_debt | Existing monthly debt payments |
| late_payments_last_12m | Late payments over the previous 12 months |
| credit_history_years | Length of credit history |
| credit_utilization | Fraction of available credit being used (0–1) |
| requested_loan_amount | Requested loan amount |
| employment_years | Years employed |
| defaulted | Target: 0 = no default, 1 = default |

## Metrics
- **Accuracy:** proportion of all predictions that are correct.
- **Precision:** of applicants predicted as default, how many actually defaulted?
- **Recall:** of all actual defaults, how many did the model identify?
- **F1:** balances precision and recall.
- **ROC-AUC:** measures how well the model ranks defaults above non-defaults across thresholds.

Do not select a credit-risk model using accuracy alone. False positives and false negatives have different consequences.

## Suggested study order
1. Read the CSV and explain each column.
2. Understand `X` (features) and `y` (target).
3. Explain why this is classification.
4. Run the script and inspect the metrics.
5. Compare precision, recall and F1.
6. Change Decision Tree `max_depth` and observe what happens.
7. Learn cross-validation before serious model tuning.
8. Later, choose a documented real dataset and verify its target definition, licence and permitted use.

Real credit decisions require much more: representative validation, privacy and security, fairness/bias assessment, explainability, human oversight and legal/regulatory review.
